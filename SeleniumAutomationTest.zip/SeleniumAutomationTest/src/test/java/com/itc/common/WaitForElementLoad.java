package com.itc.common;

import org.openqa.selenium.WebElement;

public class WaitForElementLoad {
	public static void waitForElementLaod(WebElement element) throws InterruptedException {
		try {
			int sec = 0;
			for (sec = 0; sec <= 30; sec++) {
				try {
					Thread.sleep(1000);
					sec++;
					if (element.isEnabled()) {
						//System.out.println(" : ELEMENT IS ENABLED : " + element.getAttribute("name"));
						break;
					}
				} catch (Exception e) {
				}
				//System.out.println(" : ELEMENT NOT YET ENABLED : " + element.getAttribute("name"));
			}
		} catch (Exception e) {
		}
	}
}
