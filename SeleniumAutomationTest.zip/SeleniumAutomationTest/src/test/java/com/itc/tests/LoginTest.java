package com.itc.tests;


import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.itc.pages.LoginPage;
import com.itc.util.BaseTestObject;

public class LoginTest extends BaseTestObject {
	
	LoginPage login;
	
	@Test(priority = 0)
	@Parameters({ "emailAddress", "password" })
	public void testLogin(String email, String pwd) throws InterruptedException {
		login = new LoginPage(driver);
		System.out.println("Clicking on login Tab");
		login.clickLoginTab();
		String loginPageTitle = login.getLoginTitle();
		Assert.assertTrue(loginPageTitle.contains("Login To Your Aynax Account"));
		System.out.println("Logging into Application");
		login.loginToApp(email,pwd);
		Thread.sleep(5000);
		String homePageTitle = login.getHomePageTitle();
		Assert.assertTrue(homePageTitle.contains("List of Invoices"));
	}
}
