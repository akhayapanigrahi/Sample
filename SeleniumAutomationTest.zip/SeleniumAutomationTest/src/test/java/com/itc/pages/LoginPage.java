package com.itc.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.itc.util.BasePageObject;

public class LoginPage extends BasePageObject{
	WebDriver driver;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}
	By loginTab = By.xpath("//a[@href='https://www.aynax.com/login.php']");
	By userEmailAddr = By.name("emailaddress");
	By userPwd = By.name("password");
	By titleText = By.className("loginLabel");
	By login = By.name("submit");
	By homePageTitle = By.xpath("//tbody/tr//h1");
	
	
	public void setEmailAddr(String email) {
		driver.findElement(userEmailAddr).sendKeys(email);
	}

	public void setPassword(String pwd) {
		driver.findElement(userPwd).sendKeys(pwd);
	}

	public void clickLogin() {
		driver.findElement(login).click();
	}

	public String getLoginTitle() {
		return driver.findElement(titleText).getText();
	}

	public void loginToApp(String userEmailAddr, String pwd) {
		this.setEmailAddr(userEmailAddr);
		this.setPassword(pwd);
		this.clickLogin();
	}
	
	public void clickLoginTab() {
		driver.findElement(loginTab).click();
	}

	public String getHomePageTitle() {
		return driver.findElement(homePageTitle).getText();
	}
}
