package com.itc.util;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

public class BaseTestObject {
	public WebDriver driver;

	@BeforeClass
	@Parameters({ "url", "browser" })
	public void beforeTest(String appUrl, String browserType) {
		switch (browserType) {
		case "1":
			try {
				System.out.println("Launching FireFox");
				driver = new FirefoxDriver();
				openUrl(appUrl);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;
		case "2":
			try {
				System.out.println("Launching Google Chrome");
				System.setProperty("webdriver.chrome.driver", "D:/IDeaThon/chromedriver_win32/chromedriver.exe");
				driver = new ChromeDriver();
				openUrl(appUrl);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;
		case "3":
			try {
				System.out.println("Launching Internet Explorer");
				// System.setProperty("webdriver.ie.driver",
				// "D:/IDeaThon/IEDriverServer_x64_2.53.0/IEDriverServer.exe");
				driver = new FirefoxDriver();
				openUrl(appUrl);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;
		}
		Assert.assertEquals("Online Invoicing for Small Business :: Aynax.com", driver.getTitle());
	}
	protected WebDriver openUrl(String appURL) {
		driver.get(appURL);
		System.out.println("Opening URL");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//driver.manage().window().maximize();
		return driver;
	}

}
