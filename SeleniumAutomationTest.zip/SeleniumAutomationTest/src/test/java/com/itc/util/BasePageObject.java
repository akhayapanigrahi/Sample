package com.itc.util;

public class BasePageObject {

}
