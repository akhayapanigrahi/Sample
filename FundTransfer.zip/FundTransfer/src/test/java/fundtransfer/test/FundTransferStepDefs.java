package fundtransfer.test;
import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.annotation.en.And;
import cucumber.annotation.en.Given;
import cucumber.annotation.en.When;

public class FundTransferStepDefs {
	protected WebDriver driver;
	public static String chromeDriverPath = System.getProperty("user.dir")+"\\src\\test\\resources\\drivers\\chromedriver.exe";

	@Before
	public void setUp() {
        System.setProperty("webdriver.chrome.driver",chromeDriverPath);

		driver = new ChromeDriver();
	}

@Given("the user is registered")
public void The_user_is_on_fund_transfer_page() {
driver.get("https://gecos-qa46.good.com/gecosw/");
}

	@When("he enters \"([^\"]*)\" as user name")
	public void He_enters_payee_name(String payeeName) {
		driver.findElement(By.xpath("//input[@id='IDToken1'][@placeholder='Email or Username']")).sendKeys(payeeName);
	}

	@And("he enters \"([^\"]*)\" as passowrd")
	public void He_enters_amount(String amount) {
		driver.findElement(By.xpath("//input[@id='IDToken2'][@placeholder='Password']")).sendKeys(amount);
	}

@And("he Submits request for Login")
public void He_submits_request_for_fund_transfer() {
driver.findElement(By.xpath("//input[@value='Log In'][@name='Login.Submit']")).click();
/*Behavior-driven Development
276*/
}

/*@Then("ensure the login is success")
public void Ensure_the_fund_transfer_is_complete(String msg) {
	By.linkText("App Config");
WebElement message = driver.findElement(By.id("message"));
assertEquals(message.getText(),msg);
}*/

	/*@Then
	("ensure a transaction failure message \"([^\"]*)\" isdisplayed")public void Ensure_a_transaction_failure_message(
			String msg) {
		WebElement message = driver.findElement(By.id("message"));
		assertEquals(message.getText(), msg);
	}*/

	@After
	public void tearDown() {
		driver.close();
	}
}
