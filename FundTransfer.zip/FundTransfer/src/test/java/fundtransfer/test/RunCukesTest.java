package fundtransfer.test;
import cucumber.junit.Cucumber;
import org.junit.runner.RunWith;
@RunWith(Cucumber.class)
@Cucumber.Options(features="D://MyWorkspace//FundTransfer//src//test//resources//fundtransfer//test//fundtransfer.feature",format = {"pretty", "html:target/cucumber-htmlreport","json-pretty:target/cucumber-report.json"})
public class RunCukesTest {
	
	

}
