package com.videotest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ScreenShotInChrome {

	@Test
	public void m1() throws InterruptedException{
		/*System.setProperty("webdriver.gecko.driver", "D:\\SeleniumJars\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();*/
		System.setProperty("webdriver.chrome.driver", "D:\\SeleniumJars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.naukri.com/");
		System.out.println("Hello");
        Thread.sleep(3000);
		driver.findElement(By.xpath(".//*[@id='login_Layer']/div")).click();
		driver.findElement(By.id("eLogin")).sendKeys("xxx@gmail.com");
		driver.findElement(By.id("pLogin")).sendKeys("xxx");
		driver.findElement(By.xpath("//button[@class='blueBtn' and text()='Login']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Improve Your Profile')]")).click();
		
	
		
		

	
	}
	

}
