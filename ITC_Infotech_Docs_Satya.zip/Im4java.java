package com.phoenix.edu;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.im4java.core.CompareCmd;
import org.im4java.core.IMOperation;
import org.im4java.process.StandardStream;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Im4java {
	WebDriver driver;
	public boolean compareScreenshot(String exp, String cur, String diff) throws Exception{
		CompareCmd compare=new CompareCmd();
		compare.setErrorConsumer(StandardStream.STDERR);
		  IMOperation cmpOp = new IMOperation();
		  cmpOp.metric("mae");
		 
		  cmpOp.addImage(exp);
		  cmpOp.addImage(cur);
		  cmpOp.addImage(diff);
		  
		  
		    try {
			    // Do the compare
			    compare.run(cmpOp);
			    System.out.println("True");
			    return true;
			  }
			  catch (Exception ex) {
				  System.out.println("false");
			    return false;
			  }
		
	}
	
	public void resizeImage(BufferedImage expected,BufferedImage actual){
		BufferedImage resizedImageexpected = new BufferedImage(expected.getWidth(), expected.getHeight(), BufferedImage.TYPE_INT_RGB);
		Graphics2D g1 = resizedImageexpected.createGraphics();
		g1.drawImage(expected, 0, 0, 1407, 880, null);
		g1.dispose();
		BufferedImage resizedImageactual= new BufferedImage(actual.getWidth(), actual.getHeight(), BufferedImage.TYPE_INT_RGB);
		Graphics2D g2 = resizedImageactual.createGraphics();
		g2.drawImage(actual, 0, 0, 1407, 880, null);
		g2.dispose();
		
	}
	public void resize(String inputImagePath,
            String outputImagePath, int scaledWidth, int scaledHeight)
            throws IOException {
        // reads input image
        File inputFile = new File(inputImagePath);
        BufferedImage inputImage = ImageIO.read(inputFile);
 
        // creates output image
        BufferedImage outputImage = new BufferedImage(scaledWidth,
                scaledHeight, inputImage.getType());
 
        // scales the input image to the output image
        Graphics2D g2d = outputImage.createGraphics();
        g2d.drawImage(inputImage, 0, 0, scaledWidth, scaledHeight, null);
        g2d.dispose();
 
        // extracts extension of output file
        /*String formatName = outputImagePath.substring(outputImagePath
                .lastIndexOf(".") + 1);*/
 
        // writes to output file
        ImageIO.write(outputImage, "png", new File(outputImagePath));
    }
	@Test
	public void compareImage() throws Exception{
		driver=new FirefoxDriver();
		driver.get("https://author.qa.aptimus.phoenix.edu/content/altcloud/en/accessibility.html?wcmmode=disabled");
		Thread.sleep(3000);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.id("username")).sendKeys("admin");
		driver.findElement(By.id("password")).sendKeys("admin");
		driver.findElement(By.id("submit-button")).click();
		
		new WebDriverWait(driver, 20).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(.,'Accessibility')]")));
		
		File google=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(google, new File("C:\\Users\\ssamal\\Documents\\QA.png"));
		
		//driver=new FirefoxDriver();
		driver.get("https://author.devint.aptimus.phoenix.edu/content/altcloud/en/accessibility.html?wcmmode=disabled");
		//Thread.sleep(5000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.id("username")).sendKeys("admin");
		driver.findElement(By.id("password")).sendKeys("admin");
		driver.findElement(By.id("submit-button")).click();
		
		//new WebDriverWait(driver, 20).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(.,'Accessibility')]")));
		//driver.get("https://www.facebook.com");
		File fb=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(fb, new File("C:\\Users\\ssamal\\Documents\\Dev.png"));
		
		//resizeImage(ImageIO.read(new File("C:\\Users\\ssamal\\Documents\\facebook.png")), ImageIO.read(new File("C:\\Users\\ssamal\\Documents\\google.png")));
		resize("C:\\Users\\ssamal\\Documents\\Dev.png", "C:\\Users\\ssamal\\Documents\\Devresize.png", 1407, 880);
		resize("C:\\Users\\ssamal\\Documents\\QA.png", "C:\\Users\\ssamal\\Documents\\QAresize.png", 1407, 880);
		
		compareScreenshot("C:\\Users\\ssamal\\Documents\\Devresize.png", "C:\\Users\\ssamal\\Documents\\QAresize.png", "C:\\Users\\ssamal\\Documents\\differenceresizeQA.png");
	}

}
