package com.zicos.utils;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.Reporter;

public class ExcelUtils {
	
	FileInputStream fis;
	Workbook wb;
	String xlPath;

	public ExcelUtils(String xlPath) {
		try {
		this.xlPath = xlPath;
		this.fis = new FileInputStream(this.xlPath);
		this.wb = WorkbookFactory.create(this.fis);
		} catch (Exception e) {
			Reporter.log("Failed to read file...");
			e.printStackTrace();
		}
	}

	public Sheet setSheet(String sheetName) {
		Sheet sheet = wb.getSheet(sheetName);
		return sheet;
	}

	public int getRowCount(Sheet sheet) {
		int lastRowNum = sheet.getLastRowNum();
		return lastRowNum;
	}

	public int getColCount(Sheet sheet, int rowIndex) {
		int lastColNum = sheet.getRow(rowIndex).getLastCellNum();
		return lastColNum;

	}

	public String readFromCell(Sheet sheet, int rowIndex, int cellNum) {
		Cell cell = sheet.getRow(rowIndex).getCell(cellNum);
		
		String cellText = null;
		if (cell == null)
			cellText = "";

		else if (cell.getCellType() == cell.CELL_TYPE_STRING)
			cellText = cell.getStringCellValue();

		else if (cell.getCellType() == cell.CELL_TYPE_NUMERIC)
			cellText = String.valueOf(cell.getNumericCellValue());

		else if (cell.getCellType() == cell.CELL_TYPE_BLANK)
			cellText = "";

		return cellText;
	}

	public String readFromCell(Sheet sheet, int rowIndex, String colName) {
		int colIndex = 0;
		for (int i = 0; i < getColCount(sheet, 0); i++) {

			// System.out.println(row.getCell(i).getStringCellValue().trim());
			if (sheet.getRow(0).getCell(i).getStringCellValue().trim().equalsIgnoreCase(colName))
				colIndex = i;
		}
		return readFromCell(sheet, rowIndex, colIndex);
	}

	public void writeToCell(Sheet sheet, int rowIndex, int cellNum, String value) {
		// writing the cell
		Cell writeCell = sheet.getRow(rowIndex).getCell(cellNum);
		if (writeCell == null) {
			writeCell = sheet.getRow(rowIndex).createCell(cellNum);
		}

		writeCell.setCellValue(value);
		try {
			saveExcelFile(this.xlPath);
		} catch (IOException e) {
			Reporter.log("Failed to save file");
			e.printStackTrace();
		}
	}

	public void writeToCell(Sheet sheet, int rowIndex, String colName, String value) {
		int colIndex = 0;
		for (int i = 0; i < getColCount(sheet, 0); i++) {

			// System.out.println(row.getCell(i).getStringCellValue().trim());
			if (sheet.getRow(0).getCell(i).getStringCellValue().trim().equalsIgnoreCase(colName))
				colIndex = i;
		}
		writeToCell(sheet, rowIndex, colIndex, value);
	}

	public String readDateFormat(Sheet sheet, int rowIndex, String colName) {
		int colindex = 0;
		for (int i = 0; i < getColCount(sheet, 0); i++) {
			// System.out.println(row.getCell(i).getStringCellValue().trim());
			if (sheet.getRow(0).getCell(i).getStringCellValue().trim().equalsIgnoreCase(colName))
				colindex = i;
		}
		Cell cell = sheet.getRow(rowIndex).getCell(colindex);

		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		String cellValue = sdf.format(cell.getDateCellValue());

		return cellValue;
	}

	public void saveExcelFile(String xlPath) throws IOException {
		fis.close();
		FileOutputStream fos = new FileOutputStream(xlPath);
		wb.write(fos);
		fos.close();
	}
}
