package com.zicos.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.Alert;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

public class BasePage extends BaseBrowser {
	Long maxWaitTime = new Long(30);
	
	public boolean isElementPresent(WebElement ele) {
		boolean status = false;
		try {
			status = ele.isDisplayed();
		} catch (NoSuchElementException e) {
			Reporter.log("Element not found");
		}
		return status;
	}
	
	public String executeJavascript (String javascript) {
        String output = "";
        try {
            output = String.valueOf ( ((JavascriptExecutor) getDriver ()).executeScript (javascript));
        } catch (Exception e) {
        	Reporter.log (e.getMessage ());
        }
        return output;
    }
	
	public WebElement scrollTo(WebElement el) {
		Point location = el.getLocation();
		Dimension size = el.getSize();
		int x = location.getX() - (size.getWidth() / 2);
		int y = location.getY() - (size.getHeight() / 2);
		executeJavascript(String.format("window.scroll(%s, %s)", x < 0 ? 0 : 0, y));
		return el;
	}
	
	public WebElement waitForElementVisible (WebElement ele) {
        return new WebDriverWait (getDriver (), maxWaitTime).until (ExpectedConditions.visibilityOf(ele));
    }
	
	public WebElement waitForElementClickable (WebElement ele) {
        return new WebDriverWait (getDriver (), maxWaitTime).until (ExpectedConditions.elementToBeClickable(ele));
    }
	
/*	public boolean waitForElementInvisible (WebElement ele) {
        return new WebDriverWait (getDriver (), maxWaitTime).until (ExpectedConditions.invisibilityOf(ele));
    }
*/	
	public void click (WebElement ele) {
        waitForElementVisible (ele).click();
    }
	
	public boolean jsClick(WebElement ele) {
		boolean status = false;
		try {
			JavascriptExecutor jse = (JavascriptExecutor) getDriver();
			jse.executeScript("arguments[0].click();", ele);
		} catch (Exception e) {
			Reporter.log("jsClick failed" + e);
			status = false;
		}
		return status;
	}
	
	public void setText (WebElement ele, String text) {
        try {
            scrollTo (waitForElementVisible (ele));
            ele.click ();
            ele.clear ();
            ele.sendKeys (text);
        } catch (Exception e) {
            Reporter.log(e.getMessage ());
        }
    }
	
	public String getText (WebElement ele) {
        return waitForElementVisible (ele).getText ().trim ();
    }
	
	public void hover (WebElement ele) {
        waitForElementVisible (ele);
        scrollTo (ele);
        new Actions (getDriver ()).moveToElement (ele).perform ();
    }
	
	public void switchToFrame(WebDriver driver, String id) {
		try {
			driver.switchTo().frame(id);
		} catch (Exception e){
			Reporter.log("Error....." + e.getMessage());
		}		
	}
	
	public void switchToFrame(WebDriver driver, WebElement element) {
		try {
			driver.switchTo().frame(element);
		} catch (Exception e){
			Reporter.log("Error....." + e.getMessage());
		}		
	}
	
	public void switchToFrame(WebDriver driver, int index) {
		try {
			driver.switchTo().frame(index);
		} catch (Exception e){
			Reporter.log("Error....." + e.getMessage());
		}		
	}
	
	public void switchToMultipleFrame(WebDriver driver, int frameCount) {
		try {
			for (int i=0; i<frameCount; i++)
			driver = driver.switchTo().frame(i);
		} catch (Exception e){
			Reporter.log("Error....." + e.getMessage());
		}		
	} 
	
	public void switchToDefaultWindow(WebDriver driver){
		driver.switchTo().defaultContent();
	}
	
	public void acceptAlertPopup(WebDriver driver){
		try{
			Alert alert = driver.switchTo().alert();
			alert.accept();
		} catch (NoAlertPresentException  e){
			Reporter.log("Error....." + e.getMessage());
		}
	}
	
	public void dismissAlertPopup(WebDriver driver){
		try{
			Alert alert = driver.switchTo().alert();
			alert.dismiss();
		} catch (NoAlertPresentException  e){
			Reporter.log("Error....." + e.getMessage());
		}
	}
	
	public String getAlertPopupMessage(WebDriver driver){
		try{
			Alert alert = driver.switchTo().alert();
			return alert.getText();
		} catch (NoAlertPresentException  e){
			Reporter.log("Error....." + e.getMessage());
			return null;
		}
	}
	
	public void scrollToElement(WebDriver driver, WebElement element) {
		Point location = element.getLocation();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("javascript:window.scrollBy(0,"+location.y+")");
	}
	
	public void javascriptExecutorClick(WebDriver driver, WebElement element) {
		try {
			if(element.isEnabled() && element.isDisplayed()) {
				((JavascriptExecutor) driver).executeScript("arguements[0].click(, arg1);", element);
			} 
		} catch (Exception e) {
				Reporter.log("Error....." + e.getMessage());
			}
		}
	
	public String getCurrentSystemDate(){
		DateFormat df = new SimpleDateFormat("MM/dd/YYYY");
	    Date dateobj = new Date();
	    return df.format(dateobj);
	}
	
	public String getTitle(){
		return driver.getTitle();
	}
	
	public String getUrl(){
		return driver.getCurrentUrl();
	}
}
