package com.zicos.utils;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;

public class BaseBrowser {
	protected static WebDriver driver = null;
	/*String appURL = "http://52.200.191.37:8082/zicos-test/";*/
	public static String driverPath = "src/com/zicos/resources/";
	protected static ExtentReports extentReport;
	
	private void setDriver(String browserType, String appURL) {
		switch (browserType.toLowerCase()) {
		case "chrome":
			driver = initChromeDriver(appURL);
			break;
		case "firefox":
			driver = initFirefoxDriver(appURL);
			break;
		case "ie":
			driver = initIEDriver(appURL);
			break;
		default:
			System.out.println("browser : " + browserType + " is invalid, Launching Firefox as browser of choice..");
			driver = initFirefoxDriver(appURL);
		}
	}

	private WebDriver initChromeDriver(String appURL) {
		System.out.println("Launching Chrome browser..");
		System.setProperty("webdriver.chrome.driver", driverPath + "chromedriver.exe");
		driver = new ChromeDriver();
		return driver;
	}
	
	private WebDriver initIEDriver(String appURL) {
		System.out.println("Launching IE browser..");
		System.setProperty("webdriver.ie.driver", driverPath + "IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		return driver;
	}

	private WebDriver initFirefoxDriver(String appURL) {
		System.out.println("Launching Firefox browser..");
		System.setProperty("webdriver.gecko.driver", driverPath + "geckodriver.bat");
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();			
		capabilities.setCapability("acceptInsecureCerts", true);
		capabilities.setJavascriptEnabled(true);
		//driver = (new FirefoxDriver(capabilities)); -- Deprecated
		
		FirefoxOptions options = new FirefoxOptions().setProfile(new FirefoxProfile());
		//options.addPreference("extensions.logging.enabled", false); //To turn of console logs
		driver = new FirefoxDriver(options);				
		
/*		driver = new FirefoxDriver();*/
		return driver;
	}

	
	@BeforeClass
	@Parameters({ "browserType", "appURL" })
	public void initializeTestBaseSetup(String browserType, String appURL) {
		try {
			setDriver(browserType, appURL);
			driver.manage().window().maximize();
			driver.navigate().to(appURL);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		} catch (Exception e) {
			System.out.println("Error....." + e.getMessage());
		}
	}
	
	public WebDriver getDriver() {
		return driver;
	}
	
	@AfterClass
	public void tearDown() {
		driver.quit();
	}
	
	@BeforeSuite
	@Parameters({ "browserType", "appURL" })
	public static void beforeSuite(String browserType, String appURL){
		extentReport = ExtentReport.setupExtentReport(browserType,appURL);
		
	}
	
	
	@AfterSuite
	public static void afterSuite(){
		extentReport.flush();
	}

	/*@AfterMethod
	public void takeScreenShotOnFailure(ITestResult testResult) throws IOException {
	    if (testResult.getStatus() == ITestResult.FAILURE) {
	    	String failedTestName = testResult.getTestName();
	        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	        FileUtils.copyFile(scrFile, new File(".\\screenshots\\"+failedTestName+".jpg"));
	   }        
	}*/
}
