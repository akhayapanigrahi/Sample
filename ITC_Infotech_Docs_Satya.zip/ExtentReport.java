package com.zicos.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReport {

	private static String filePath = "src/com/zicos/resources/";
	private static String reportPath = filePath+"extendReport.html";
	private static String logoPath =  "itcInfotech1.jpg";
	
	public static ExtentReports setupExtentReport(String browserType, String url) {
		ExtentHtmlReporter html = new ExtentHtmlReporter(reportPath);
		System.out.println(reportPath);
		html.config().setChartVisibilityOnOpen(true);
		html.config().setDocumentTitle("Automation Test Execution Report");
		html.config().setReportName(
				"<img align='center' src='"+logoPath+"' /> 	Automation Test Report -  ZICOS");
		
		html.config().setTheme(Theme.STANDARD);
		;
		html.getExceptionContextInfo();
		ExtentReports extendReports = new ExtentReports();
		extendReports.setSystemInfo("Environment", "QA");
		extendReports.setSystemInfo("Browser", browserType);
		extendReports.setSystemInfo("Application URL", url);

		extendReports.attachReporter(html);
		return extendReports;
	}

}
