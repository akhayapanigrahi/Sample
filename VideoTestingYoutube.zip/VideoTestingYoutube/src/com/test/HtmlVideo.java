package com.test;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class HtmlVideo {
	  
public WebDriver driver;
  
@Test
public void testVideo() throws InterruptedException
{  
 driver = new FirefoxDriver();
 driver.manage().window().maximize();
 driver.get("http://gmail.com");
/* driver.get("https://www.youtube.com/watch?v=Tq8phJ6X9sU");
 JavascriptExecutor js = (JavascriptExecutor) driver;
//pause playing video 
js .executeScript("document.getElementById(\"movie_player\").pause()");
 //play video
 js .executeScript("document.getElementById(\"movie_player\").play()");
 Thread.sleep(5000);*/
   
 
 /*  
 //check video is paused
 System.out.println(js .executeScript("document.getElementById(\"video\").paused"));
   
 js .executeScript("document.getElementById(\"video\").play()");
   
 // play video from starting
 js .executeScript("document.getElementById(\"video\").currentTime=0");
 Thread.sleep(5000);
   
 //reload video
 js .executeScript("document.getElementById(\"video\").load()");*/
}
}

